#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Timer.h"
#include "AS5600.h"
float Angle;
uint16_t Num;

int main(void)
{
	OLED_Init();
	Timer_Init();
	AS5600_Init();
 
	while (1)
	{
		
		Angle=AS5600_ReadRawAngleTwo()*0.08789;
		OLED_ShowNum(2,1,(uint16_t)(Angle),3);
		OLED_ShowString(2, 4, ".");
		OLED_ShowNum(2,5,(uint16_t)(Angle*100)%10,1);
		OLED_ShowNum(1, 1, Num, 5);
		
	}
}

void TIM2_IRQHandler(void)
{
	if (TIM_GetITStatus(TIM2, TIM_IT_Update) == SET)
	{
		Num ++;
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
	}
}

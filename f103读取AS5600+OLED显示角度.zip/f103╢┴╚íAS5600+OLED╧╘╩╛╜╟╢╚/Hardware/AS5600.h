#ifndef __AS5600_H
#define __AS5600_H

#define  RAW_Angle_Hi    0x0C
#define  RAW_Angle_Lo    0x0D
#define  AS5600_Address  0x36
/***************************************************************************/
#define SDA_IN()  {GPIOB->CRH&=0xFFFF0FFF;GPIOB->CRH|=0x00008000;}
#define SDA_OUT() {GPIOB->CRH&=0xFFFF0FFF;GPIOB->CRH|=0x00003000;}
#define READ_SDA  (GPIOB->IDR&(1<<11))
#define IIC_SCL_1  GPIO_SetBits(GPIOB,GPIO_Pin_10)
#define IIC_SCL_0  GPIO_ResetBits(GPIOB,GPIO_Pin_10)
#define IIC_SDA_1  GPIO_SetBits(GPIOB,GPIO_Pin_11)
#define IIC_SDA_0  GPIO_ResetBits(GPIOB,GPIO_Pin_11)

void AS5600_Init(void);
void delay_s(u32 i);
void IIC_Start(void);
void IIC_Stop(void);
u8 IIC_Wait_Ack(void);
void IIC_Ack(void);
void IIC_NAck(void);
void IIC_Send_Byte(u8 txd);
u8 IIC_Read_Byte(u8 ack);
u8 AS5600_ReadOneByte(u8 addr);
u16 AS5600_ReadRawAngleTwo(void);

#endif

